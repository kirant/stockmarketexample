package com.jpmc.cqrs.core.exceptions;

public class ConcurrencyException extends RuntimeException {
}
