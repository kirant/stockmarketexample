package com.jpmc.cqrs.core.queries;

public abstract class BaseQuery {
}
