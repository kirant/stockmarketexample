package com.jpmc.cqrs.core.domain;

public abstract class BaseEntity {
}
