package com.jpmc.account.query.domain;

import com.jpmc.trade.common.dto.TradeType;
import com.jpmc.cqrs.core.domain.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
public class Trade extends BaseEntity {
    @Id
    private String id;
    private String symbol;;
    private TradeType type;
    private Double tradePrice;
    private Long sharesQuantity;
    private Date createdDate;
}
