package com.jpmc.account.query.api.queries;

import com.jpmc.cqrs.core.queries.BaseQuery;

public class FindAllTradesQuery extends BaseQuery {
}
