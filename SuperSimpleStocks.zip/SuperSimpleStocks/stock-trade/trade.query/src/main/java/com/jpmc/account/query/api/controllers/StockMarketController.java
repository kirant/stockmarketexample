package com.jpmc.account.query.api.controllers;


import com.jpmc.account.query.api.dto.GetGBCEResponse;
import com.jpmc.account.query.service.StockMarketService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/exchange")
public class StockMarketController {

	@Autowired
	private StockMarketService stockMarketService;

	@RequestMapping(value = "/gbce", method = RequestMethod.GET)
	public GetGBCEResponse getGBCEIndex() {
		Double gbce = stockMarketService.getGBCE();
		GetGBCEResponse response = GetGBCEResponse.builder().gbce(gbce).build();
		return response;
	}

}
