package com.jpmc.account.query.infrastructure.consumers;

import com.jpmc.trade.common.events.StockBuyEvent;
import com.jpmc.trade.common.events.StockSellEvent;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.handler.annotation.Payload;

public interface EventConsumer {
    void consume(@Payload StockBuyEvent event, Acknowledgment ack);
    void consume(@Payload StockSellEvent event, Acknowledgment ack);
}
