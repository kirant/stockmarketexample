package com.jpmc.account.query.api.queries;

import com.jpmc.cqrs.core.queries.BaseQuery;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class FindTradesInLastMinutesQuery extends BaseQuery {
    private int minutes;
}
