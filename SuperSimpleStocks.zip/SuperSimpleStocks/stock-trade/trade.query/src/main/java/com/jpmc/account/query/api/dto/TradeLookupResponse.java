package com.jpmc.account.query.api.dto;

import com.jpmc.trade.common.dto.BaseResponse;
import com.jpmc.account.query.domain.Trade;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.List;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class TradeLookupResponse extends BaseResponse {
    private List<Trade> trades;

    public TradeLookupResponse(String message) {
        super(message);
    }
}
