package com.jpmc.account.query.infrastructure.handlers;

import com.jpmc.account.query.domain.Trade;
import com.jpmc.account.query.domain.TradeRepository;
import com.jpmc.trade.common.events.StockBuyEvent;
import com.jpmc.trade.common.events.StockSellEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TradeEventHandler implements EventHandler {


    @Autowired
    private TradeRepository tradeRepository;



    @Override
    public void on(StockSellEvent event) {
        var trade = Trade.builder()
                .id(event.getId())
                .tradePrice(event.getTradePrice())
                .createdDate(event.getCreatedDate())
                .sharesQuantity(event.getSharesQuantity())
                .symbol(event.getSymbol())
                .type(event.getType())
                .build();
        tradeRepository.save(trade);
    }

    @Override
    public void on(StockBuyEvent event) {
        var trade = Trade.builder()
                .id(event.getId())
                .tradePrice(event.getTradePrice())
                .createdDate(event.getCreatedDate())
                .sharesQuantity(event.getSharesQuantity())
                .symbol(event.getSymbol())
                .type(event.getType())
                .build();
        tradeRepository.save(trade);

    }
}
