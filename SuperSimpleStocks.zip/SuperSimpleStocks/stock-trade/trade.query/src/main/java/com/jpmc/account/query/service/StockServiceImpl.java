package com.jpmc.account.query.service;


import com.jpmc.account.query.api.queries.FindAllTradesQuery;
import com.jpmc.account.query.domain.Stock;
import com.jpmc.account.query.domain.StockType;
import com.jpmc.account.query.domain.Trade;
import com.jpmc.account.query.domain.StockRepository;
import com.jpmc.cqrs.core.infrastructure.QueryDispatcher;
import org.apache.catalina.connector.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StockServiceImpl implements StockService {
	private static final Logger log = LoggerFactory.getLogger(StockServiceImpl.class);
	
	@Value("${minutes.for.last.trades:15}")
	private Integer minutes;
	
	@Autowired
	private StockRepository stockRepository;

	@Autowired
	private QueryDispatcher queryDispatcher;

	@Override
	public Double getDividendYield(String stockSymbol, Double stockPrice) throws Exception {
		log.debug("Finding Div Yield with Symbol {}, stockPrice {} ", stockSymbol, stockPrice);
		Stock stock = getStock(stockSymbol);
		Double dividendYield = null;
		if(StockType.Common == stock.getType()){
			dividendYield = stock.getLastDividend()/stockPrice;
		} else{
			dividendYield = (stock.getFixedDividend() * stock.getParValue())/stockPrice;
		}
		
		log.debug("Div Yield {} with Symbol {}, stockPrice {} ", dividendYield, stockSymbol, stockPrice);
		return dividendYield;
	}

	@Override
	public Stock getStock(String stockSymbol) throws Exception {
		log.debug("Finding stock with Symbol {} ", stockSymbol);
		Stock stock = stockRepository.findStockBySymbol(stockSymbol);
		
		if(stock == null){
			log.error("Not able to find the Stock {} ", stockSymbol);
			throw new Exception(Response.SC_NOT_FOUND + "Stock ["+stockSymbol+"] is invalid");
		}
		log.debug("Found Stock[{}] with Symbol {} ", stock, stockSymbol);
		return stock;
	}

	@Override
	public Double getPERatio(String symbol, Double stockPrice) throws Exception {
		log.debug("Finding PE Ratio with Symbol {} and StockPrice {}", symbol, stockPrice);
		Double dividendYield = getDividendYield(symbol, stockPrice);
		Double peRatio = stockPrice / dividendYield;
		log.debug("PE Ratio {} with Symbol {} and StockPrice {}", peRatio, symbol, stockPrice);
		return peRatio;
	}

	@Override
	public Double getVolWeightedPice(String symbol) {
		log.debug("Finding Vol Weighted Price with Symbol {} ", symbol);
		Stock stock = stockRepository.findStockBySymbol(symbol);

		List<Trade> trades = queryDispatcher.send(new FindAllTradesQuery());
		Double volWeightedPrice = 0d;
		Long quantity = 0l;
		if (trades != null) {
			for (Trade trade : trades) {
				quantity += trade.getSharesQuantity();
				volWeightedPrice += trade.getSharesQuantity() * trade.getTradePrice();
			}
			volWeightedPrice /= quantity;
		}
		log.debug("Vol Weighted Price {} with Symbol {}", volWeightedPrice, symbol);
		return volWeightedPrice;
	}	
	


	
}
