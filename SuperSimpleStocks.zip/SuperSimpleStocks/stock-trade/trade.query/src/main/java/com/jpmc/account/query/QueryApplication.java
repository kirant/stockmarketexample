package com.jpmc.account.query;

import com.jpmc.account.query.api.queries.BaseTradeQueryHandler;
import com.jpmc.account.query.api.queries.FindAllTradesQuery;
import com.jpmc.account.query.api.queries.FindTradesInLastMinutesQuery;
import com.jpmc.cqrs.core.infrastructure.QueryDispatcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.annotation.PostConstruct;

@SpringBootApplication
public class QueryApplication {
	@Autowired
	private QueryDispatcher queryDispatcher;

	@Autowired
	private BaseTradeQueryHandler queryHandler;



	public static void main(String[] args) {
		SpringApplication.run(QueryApplication.class, args);
		SQLInserts.insertStockData();
	}

	@PostConstruct
	public void registerHandlers() {
		queryDispatcher.registerHandler(FindAllTradesQuery.class, queryHandler::handle);
		queryDispatcher.registerHandler(FindTradesInLastMinutesQuery.class, queryHandler::handle);
	}
}
