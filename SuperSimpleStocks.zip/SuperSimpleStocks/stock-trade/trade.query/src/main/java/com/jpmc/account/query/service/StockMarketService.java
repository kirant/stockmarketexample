package com.jpmc.account.query.service;

public interface StockMarketService{

	Double getGBCE();

}
