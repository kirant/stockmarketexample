package com.jpmc.account.query.domain;

public enum StockType {
    Common,
    Preferred
}
