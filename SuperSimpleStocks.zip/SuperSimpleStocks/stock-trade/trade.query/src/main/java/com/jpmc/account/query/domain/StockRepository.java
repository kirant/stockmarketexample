package com.jpmc.account.query.domain;


import org.springframework.data.repository.CrudRepository;


import com.jpmc.account.query.domain.Stock;

import java.util.List;

public interface StockRepository extends  CrudRepository<Stock, String> {

	Stock findStockBySymbol(String symbol);
}
