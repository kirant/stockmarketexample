package com.jpmc.account.query.api.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * DividendYield Response Class
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GetDividendYieldResponse {
	private String symbol;
	
	private Double stockPrice;
	
	private Double dividendYield;



}
