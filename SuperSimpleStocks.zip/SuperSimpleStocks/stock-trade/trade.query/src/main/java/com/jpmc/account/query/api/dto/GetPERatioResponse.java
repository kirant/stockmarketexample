package com.jpmc.account.query.api.dto;

//import io.swagger.annotations.ApiModelProperty;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;

/**
 * PE Ratio Response Class
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class GetPERatioResponse {

	private String symbol;
	
	private Double stockPrice;
	
	private Double peRatio;



}
