package com.jpmc.account.query.infrastructure.consumers;

import com.jpmc.account.query.infrastructure.handlers.EventHandler;
import com.jpmc.trade.common.events.StockBuyEvent;
import com.jpmc.trade.common.events.StockSellEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

@Service
public class TradeEventConsumer implements EventConsumer {
    @Autowired
    private EventHandler eventHandler;


    @KafkaListener(topics = "StockBuyEvent", groupId = "${spring.kafka.consumer.group-id}")
    @Override
    public void consume(@Payload StockBuyEvent event, Acknowledgment ack) {
        this.eventHandler.on(event);
        ack.acknowledge();
    }

    @KafkaListener(topics = "StockSellEvent", groupId = "${spring.kafka.consumer.group-id}")
    @Override
    public void consume(@Payload StockSellEvent event, Acknowledgment ack) {
        this.eventHandler.on(event);
        ack.acknowledge();
    }
}
