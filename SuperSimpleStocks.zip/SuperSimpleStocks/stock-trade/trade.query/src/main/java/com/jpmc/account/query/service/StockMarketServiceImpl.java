package com.jpmc.account.query.service;

import com.jpmc.account.query.api.queries.FindAllTradesQuery;
import com.jpmc.account.query.domain.Trade;
import com.jpmc.cqrs.core.infrastructure.QueryDispatcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StockMarketServiceImpl implements StockMarketService {
	
	private static final Logger log = LoggerFactory.getLogger(StockMarketServiceImpl.class);

	@Autowired
	private QueryDispatcher queryDispatcher;

	@Override
	public Double getGBCE() {
		log.debug("Getting GBCE");
		List<Trade> trades = queryDispatcher.send(new FindAllTradesQuery());

		Double gbce = 0d;
		
		if(trades != null && trades.size() != 0){
			Double priceProduct = 1d;
			for(Trade trade : trades){
				priceProduct*=trade.getTradePrice();
			}
			Double n = (double)trades.size();
			
			gbce = Math.pow(priceProduct, 1d/n);
		}
		
		log.debug("Got GBCE [{}]", gbce);
		
		return gbce;
	}

	
}
