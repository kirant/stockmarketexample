package com.jpmc.account.query.service;


import com.jpmc.account.query.domain.Stock;


public interface StockService {
	Double getDividendYield(String stockSymbol, Double stockPrice) throws Exception;
	
	Stock getStock(String stockSymbol) throws Exception;

	Double getPERatio(String symbol, Double stockPrice) throws Exception;
	
	Double getVolWeightedPice(String symbol);

}
