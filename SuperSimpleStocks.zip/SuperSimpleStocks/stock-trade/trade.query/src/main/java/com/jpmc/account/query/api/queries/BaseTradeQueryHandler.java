package com.jpmc.account.query.api.queries;

import com.jpmc.cqrs.core.domain.BaseEntity;

import java.util.List;

public interface BaseTradeQueryHandler {
    List<BaseEntity> handle(FindAllTradesQuery query);
    List<BaseEntity> handle(FindTradesInLastMinutesQuery query);
}
