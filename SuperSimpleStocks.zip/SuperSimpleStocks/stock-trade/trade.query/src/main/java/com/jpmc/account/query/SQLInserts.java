package com.jpmc.account.query;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class SQLInserts {
    // JDBC driver name and database URL
    static final String JDBC_DRIVER = "org.h2.Driver";
    static final String DB_URL = "jdbc:h2:mem:stocksdata";

    //  Database credentials
    static final String USER = "sa";
    static final String PASS = "password";

    public static void insertStockData() {
        Connection conn = null;
        Statement stmt = null;

        try {
            //STEP 2: Register JDBC driver
            Class.forName(JDBC_DRIVER);

            //STEP 3: Open a connection
            System.out.println("Connecting to a selected database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected database successfully...");

            //STEP 4: Execute a query
            System.out.println("Inserting records into the table...");
            stmt = conn.createStatement();

            String sql = "INSERT INTO stock " + "VALUES (1,0,0,100,'TEA', 0)";
            stmt.executeUpdate(sql);
            sql = "INSERT INTO stock " + "VALUES (2,0,8,100,'POP', 0)";
            stmt.executeUpdate(sql);
            sql = "INSERT INTO stock " + "VALUES (3,0,23,60,'ALE', 0)";
            stmt.executeUpdate(sql);
            sql = "INSERT INTO stock " + "VALUES (4,0.02,8,100,'GIN', 1)";
            stmt.executeUpdate(sql);
            sql = "INSERT INTO stock " + "VALUES (5,0,13,250,'JOE', 0)";
            stmt.executeUpdate(sql);
            System.out.println("Inserted records into the table...");

        } catch (SQLException se) {
            //Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            //finally block used to close resources
            try {
                if (stmt!=null)
                    conn.close();
            } catch (SQLException se) {
            } // do nothing
            try {
                if (conn!=null)
                    conn.close();
            } catch (SQLException se) {
                se.printStackTrace();
            } //end finally try
        } //end try

        System.out.println("Goodbye!");

    } //end main
} //end JDBCExample
