package com.jpmc.account.query.api.controllers;



import com.jpmc.account.query.api.dto.GetDividendYieldResponse;
import com.jpmc.account.query.api.dto.GetPERatioResponse;
import com.jpmc.account.query.api.dto.GetVolWeightedResponse;
import com.jpmc.account.query.service.StockService;
import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/v1/exchange")
public class StockController {

	@Autowired
	private StockService stockService;

	@RequestMapping(value = "/stock/{symbol}/dividendyield", method = RequestMethod.GET)
	public GetDividendYieldResponse getDividentYield(@RequestParam(required = true) Double stockPrice,
													 @PathVariable(required=true,name="symbol") String symbol) throws Exception {
		if (stockPrice <= 0) {
			throw new Exception(Response.SC_BAD_REQUEST + "stockPrice should be positive");
		}
		Double dividendYield = stockService.getDividendYield(symbol, stockPrice);
		GetDividendYieldResponse response = GetDividendYieldResponse.builder().dividendYield(dividendYield)
				.stockPrice(stockPrice).symbol(symbol).build();
		return response;
	}

	@RequestMapping(value = "/stock/{symbol}/peratio", method = RequestMethod.GET)
	public GetPERatioResponse getPERatio(@RequestParam(required = true) Double stockPrice,
										 @PathVariable("symbol") String symbol) throws Exception {
		if (stockPrice <= 0) {
			throw new Exception(Response.SC_BAD_REQUEST + "stockPrice should be positive");
		}

		Double peRatio = stockService.getPERatio(symbol, stockPrice);
		GetPERatioResponse response =  GetPERatioResponse.builder().peRatio(peRatio).stockPrice(stockPrice)
				.symbol(symbol).build();
		return response;
	}

	@RequestMapping(value = "/stock/{symbol}/vwprice", method = RequestMethod.GET)
	public GetVolWeightedResponse getVolumeWeightedPrice(@PathVariable("symbol") String symbol) {
		Double volWeightedPrice = stockService.getVolWeightedPice(symbol);

		GetVolWeightedResponse response = GetVolWeightedResponse.builder().symbol(symbol)
				.volWeighedPrice(volWeightedPrice).build();
		return response;
	}
}
