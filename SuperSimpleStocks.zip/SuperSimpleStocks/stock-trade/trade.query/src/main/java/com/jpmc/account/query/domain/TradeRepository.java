package com.jpmc.account.query.domain;

import com.jpmc.cqrs.core.domain.BaseEntity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface TradeRepository extends CrudRepository<Trade, String> {

    List<Trade> findTradesByCreatedDateAfter(Date date);

}
