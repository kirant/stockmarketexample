package com.jpmc.account.query.infrastructure.handlers;

import com.jpmc.trade.common.events.StockBuyEvent;
import com.jpmc.trade.common.events.StockSellEvent;

public interface EventHandler {

    void on(StockSellEvent event);

    void on(StockBuyEvent event);
}
