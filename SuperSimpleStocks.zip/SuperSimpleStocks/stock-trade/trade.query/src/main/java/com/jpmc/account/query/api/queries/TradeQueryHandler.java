package com.jpmc.account.query.api.queries;

import com.jpmc.account.query.domain.Trade;
import com.jpmc.account.query.domain.TradeRepository;
import com.jpmc.cqrs.core.domain.BaseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
public class TradeQueryHandler implements BaseTradeQueryHandler {
    @Autowired
    private TradeRepository tradeRepository;

    @Override
    public List<BaseEntity> handle(FindAllTradesQuery query) {
        Iterable<Trade> trades = tradeRepository.findAll();
        List<BaseEntity> tradesList = new ArrayList<>();
        trades.forEach(tradesList::add);
        return tradesList;
    }

    @Override
    public List<BaseEntity> handle(FindTradesInLastMinutesQuery query) {
        LocalDateTime dateTime = LocalDateTime.now().minus(Duration.of(query.getMinutes(), ChronoUnit.MINUTES));
        Date tmfn = Date.from(dateTime.atZone(ZoneId.systemDefault()).toInstant());
        Iterable<Trade> trades = tradeRepository.findTradesByCreatedDateAfter(tmfn);
        List<BaseEntity> tradesList = new ArrayList<>();
        trades.forEach(tradesList::add);
        return tradesList;
    }

}
