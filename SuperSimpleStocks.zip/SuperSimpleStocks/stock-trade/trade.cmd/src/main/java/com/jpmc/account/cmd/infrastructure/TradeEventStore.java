package com.jpmc.account.cmd.infrastructure;

import com.google.gson.Gson;
import com.jpmc.account.cmd.domain.EventModel;
import com.jpmc.account.cmd.domain.EventStoreRepository;
import com.jpmc.account.cmd.domain.TradeAggregate;
import com.jpmc.trade.common.events.StockBuyEvent;
import com.jpmc.trade.common.events.StockSellEvent;
import com.jpmc.cqrs.core.events.BaseEvent;
import com.jpmc.cqrs.core.exceptions.AggregateNotFoundException;
import com.jpmc.cqrs.core.exceptions.ConcurrencyException;
import com.jpmc.cqrs.core.infrastructure.EventStore;
import com.jpmc.cqrs.core.producers.EventProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

@Service
public class TradeEventStore implements EventStore {
    private final Logger logger = Logger.getLogger(TradeEventStore.class.getName());

    @Autowired
    private EventProducer eventProducer;

    @Autowired
    private EventStoreRepository eventStoreRepository;

    Gson gson = new Gson();

    @Override
    public void saveEvents(String aggregateId, Iterable<BaseEvent> events, int expectedVersion) {
        var eventStream = eventStoreRepository.findByAggregateIdentifier(aggregateId);
        if (expectedVersion != -1 && eventStream.get(eventStream.size() - 1).getVersion() != expectedVersion) {
            throw new ConcurrencyException();
        }
        var version = expectedVersion;
        String eventData;
        for (var event: events) {
           version++;
           event.setVersion(version);
           var eventModel = EventModel.builder()
                   .timeStamp(new Date())
                   .aggregateIdentifier(aggregateId)
                   .aggregateType(TradeAggregate.class.getTypeName())
                   .version(version)
                   .eventType(event.getClass().getTypeName())
                   .eventData(gson.toJson(event))
                   .build();
            System.out.println(" Haribol" + event.getClass().getSimpleName());

            var persistedEvent = eventStoreRepository.save(eventModel);
           logger.info("The persisted data" + eventModel.toString());
            logger.log(Level.SEVERE, MessageFormat.format("The persisted data {0}" , eventModel.toString()));
              System.out.println(event.toString());
            eventProducer.produce(event.getClass().getSimpleName(), event);

/*            if (!persistedEvent.getId().isEmpty()) {
               eventProducer.produce(event.getClass().getSimpleName(), event);
           }*/
        }
    }



    @Override
    public List<BaseEvent> getEvents(String aggregateId) {
        var eventStream = eventStoreRepository.findByAggregateIdentifier(aggregateId);
        if (eventStream == null || eventStream.isEmpty()) {
            throw new AggregateNotFoundException("Incorrect account ID provided!");
        }

        return eventStream.stream().map(x ->{

            if(x.getEventType().equalsIgnoreCase("com.jpmc.account.common.events.StockBuyEvent")){
                return gson.fromJson(x.getEventData(), StockBuyEvent.class);
            } else  {
                return gson.fromJson(x.getEventData(), StockSellEvent.class);
            }

        } ).collect(Collectors.toList());
    }

    @Override
    public List<String> getAggregateIds() {
       // var eventStream = eventStoreRepository.findAll();
        Iterable<EventModel> i=eventStoreRepository.findAll();
        List<EventModel> eventStream= new ArrayList<EventModel>();
        Iterator<EventModel> itr=i.iterator();
        while(itr.hasNext()){
            EventModel cn=itr.next();
            eventStream.add(cn);
        }
        if (eventStream == null || eventStream.isEmpty()) {
            throw new IllegalStateException("Could not retrieve event stream from the event store!");
        }
        return eventStream.stream().map(EventModel::getAggregateIdentifier).distinct().collect(Collectors.toList());
    }
}
