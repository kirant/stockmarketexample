package com.jpmc.account.cmd.api.controllers;

import com.jpmc.account.cmd.api.commands.TradeStockCommand;
import com.jpmc.account.cmd.api.dto.TradeStockResponse;
import com.jpmc.trade.common.dto.BaseResponse;
import com.jpmc.cqrs.core.infrastructure.CommandDispatcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.text.MessageFormat;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

@RestController
@RequestMapping(path = "/api/v1/trade")
public class TradeController {
    private final Logger logger = Logger.getLogger(TradeController.class.getName());

    @Autowired
    private CommandDispatcher commandDispatcher;

    @PostMapping
    public ResponseEntity<BaseResponse> startTrade(@RequestBody TradeStockCommand command) {
        var id = UUID.randomUUID().toString();
        command.setId(id);
        try {
            System.out.println("hey command id is " + command.getId());
            commandDispatcher.send(command);
            return new ResponseEntity<>(new TradeStockResponse("Trade request completed successfully!", id), HttpStatus.CREATED);
        } catch (IllegalStateException e) {
            logger.log(Level.WARNING, MessageFormat.format("Client made a bad request - {0}.", e.toString()));
            return new ResponseEntity<>(new BaseResponse(e.toString()), HttpStatus.BAD_REQUEST);
        } catch (Exception e) {
            var safeErrorMessage = MessageFormat.format("Error while processing trade request for id - {0}.", id);
            logger.log(Level.SEVERE, safeErrorMessage, e);
            return new ResponseEntity<>(new TradeStockResponse(safeErrorMessage, id), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
