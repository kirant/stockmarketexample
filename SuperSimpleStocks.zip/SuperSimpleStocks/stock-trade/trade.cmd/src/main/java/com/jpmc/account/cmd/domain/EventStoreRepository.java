package com.jpmc.account.cmd.domain;

import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface EventStoreRepository extends CrudRepository<EventModel, String> {
    List<EventModel> findByAggregateIdentifier(String aggregateIdentifier);
}
