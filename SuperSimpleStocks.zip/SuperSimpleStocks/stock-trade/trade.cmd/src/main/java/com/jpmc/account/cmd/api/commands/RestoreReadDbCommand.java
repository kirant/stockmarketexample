package com.jpmc.account.cmd.api.commands;

import com.jpmc.cqrs.core.commands.BaseCommand;

public class RestoreReadDbCommand extends BaseCommand {
}
