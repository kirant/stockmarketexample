package com.jpmc.account.cmd.domain;


import com.jpmc.account.cmd.api.commands.TradeStockCommand;
import com.jpmc.trade.common.dto.TradeType;
import com.jpmc.cqrs.core.domain.AggregateRoot;
import com.jpmc.trade.common.events.StockBuyEvent;
import com.jpmc.trade.common.events.StockSellEvent;
import lombok.NoArgsConstructor;

import java.util.Date;

@NoArgsConstructor
public class TradeAggregate extends AggregateRoot {

    public TradeAggregate(TradeStockCommand tradeStockCommand) {
        if(tradeStockCommand.getSharesQuantity() <= 0) {
            throw new IllegalStateException("The quantity must be greater than 0!");
        }

        if(tradeStockCommand.getType().equals(TradeType.Buy)) {
            raiseEvent(StockBuyEvent.builder()
                    .id(tradeStockCommand.getId())
                    .symbol(tradeStockCommand.getSymbol())
                    .type(tradeStockCommand.getType())
                    .tradePrice(tradeStockCommand.getTradePrice())
                    .sharesQuantity(tradeStockCommand.getSharesQuantity())
                    .createdDate(new Date())
                    .build());
        } else {
            raiseEvent(StockSellEvent.builder()
                    .id(tradeStockCommand.getId())
                    .symbol(tradeStockCommand.getSymbol())
                    .type(tradeStockCommand.getType())
                    .tradePrice(tradeStockCommand.getTradePrice())
                    .sharesQuantity(tradeStockCommand.getSharesQuantity())
                    .createdDate(new Date())
                    .build());
        }
    }


    public void apply(StockBuyEvent event) {
        this.id = event.getId();
    }

    public void apply(StockSellEvent event) {
        this.id = event.getId();
    }


}
