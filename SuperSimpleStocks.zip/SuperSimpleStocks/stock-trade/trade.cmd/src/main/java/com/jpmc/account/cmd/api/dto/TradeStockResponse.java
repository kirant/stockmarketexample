package com.jpmc.account.cmd.api.dto;

import com.jpmc.trade.common.dto.BaseResponse;
import lombok.Data;

@Data
public class TradeStockResponse extends BaseResponse {
    private String id;

    public TradeStockResponse(String message, String id) {
        super(message);
        this.id = id;
    }
}
