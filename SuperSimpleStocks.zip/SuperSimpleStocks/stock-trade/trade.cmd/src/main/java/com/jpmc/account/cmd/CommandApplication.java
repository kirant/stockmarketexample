package com.jpmc.account.cmd;

import com.jpmc.account.cmd.api.commands.*;
import com.jpmc.cqrs.core.infrastructure.CommandDispatcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.annotation.PostConstruct;

@SpringBootApplication
public class CommandApplication {

	@Autowired
	private CommandDispatcher commandDispatcher;

	@Autowired
	private CommandHandler commandHandler;

	public static void main(String[] args) {
		SpringApplication.run(CommandApplication.class, args);
	}

	@PostConstruct
	public void registerHandlers() {
		commandDispatcher.registerHandler(RestoreReadDbCommand.class, commandHandler::handle);
		commandDispatcher.registerHandler(TradeStockCommand.class,commandHandler::handle);
	}

}
