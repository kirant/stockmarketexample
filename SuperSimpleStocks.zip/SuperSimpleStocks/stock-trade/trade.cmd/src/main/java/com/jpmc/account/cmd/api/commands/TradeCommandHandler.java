package com.jpmc.account.cmd.api.commands;

import com.jpmc.account.cmd.domain.TradeAggregate;
import com.jpmc.cqrs.core.handlers.EventSourcingHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

// The 'ConcreteColleague' class
@Service
public class TradeCommandHandler implements CommandHandler {
    @Autowired
    private EventSourcingHandler<TradeAggregate> eventSourcingHandler;


    @Override
    public void handle(RestoreReadDbCommand command) {
        eventSourcingHandler.republishEvents();
    }


    @Override
    public void handle(TradeStockCommand command) {
        var aggregate = new TradeAggregate(command);
        eventSourcingHandler.save(aggregate);
    }
}
