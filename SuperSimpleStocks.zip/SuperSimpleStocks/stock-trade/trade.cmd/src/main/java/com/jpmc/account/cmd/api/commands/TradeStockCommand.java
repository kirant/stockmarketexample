package com.jpmc.account.cmd.api.commands;

import com.jpmc.trade.common.dto.TradeType;
import com.jpmc.cqrs.core.commands.BaseCommand;
import lombok.Data;

@Data
public class TradeStockCommand extends BaseCommand {
    private String symbol;;
    private TradeType type;
    private Double tradePrice;
    private Long sharesQuantity;
}
