package com.jpmc.account.cmd.api.commands;

// The 'AbstractColleague'
public interface CommandHandler {

    void handle(RestoreReadDbCommand command);

    void handle(TradeStockCommand command);

}
