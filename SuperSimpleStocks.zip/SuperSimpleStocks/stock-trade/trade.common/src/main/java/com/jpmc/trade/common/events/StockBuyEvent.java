package com.jpmc.trade.common.events;

import com.jpmc.trade.common.dto.TradeType;
import com.jpmc.cqrs.core.events.BaseEvent;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@SuperBuilder
public class StockBuyEvent extends BaseEvent {

    private String symbol;;
    private TradeType type;
    private Double tradePrice;
    private Long sharesQuantity;
    private Date createdDate;
}
