package com.jpmc.trade.common.dto;

public enum TradeType {
    Buy,
    Sell
}
