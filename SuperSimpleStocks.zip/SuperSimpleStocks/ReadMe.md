
The following code has 2 microservices trade.cmd and trade.query.

trade.cmd handles the inflow of trades and writes them as events, 
in a event store. The store is designed write only. It sends data via Kafka to
read service trade.query.

trade.query is used for market data publishing, it has a read only store of published trade data and stock information. from which dividend yield,
P/E Ratio,Volume Weighted Stock Price, Share Index service are available.

InMemory database H2 used as data and event store and can be accessed at : localhost:5000/h2-console for event store and localhost:5001/h2-console for eventsdatastore.

User docker-compose.yml to load Kafka and Zookeeper.

cqrs and trade.common are support packages.

